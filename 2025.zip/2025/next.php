<?php
// Initialize variables
$name = $email = $subject = $message = "";
$nameErr = $emailErr = $subjectErr = $messageErr = "";
$successMsg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $valid = true;

    // Sanitize and validate name
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
        $valid = false;
    } else {
        $name = htmlspecialchars(strip_tags(trim($_POST["name"])));
        if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
            $nameErr = "Only letters and white space allowed";
            $valid = false;
        }
    }

    // Sanitize and validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
        $valid = false;
    } else {
        $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
            $valid = false;
        }
    }

    // Sanitize and validate subject
    if (empty($_POST["subject"])) {
        $subjectErr = "Subject is required";
        $valid = false;
    } else {
        $subject = htmlspecialchars(strip_tags(trim($_POST["subject"])));
    }

    // Sanitize and validate message
    if (empty($_POST["message"])) {
        $messageErr = "Message is required";
        $valid = false;
    } else {
        $message = htmlspecialchars(strip_tags(trim($_POST["message"])));
    }

    // If all fields valid, display success message (or you can add mail sending logic)
    if ($valid) {
        $successMsg = "Thank you, $name! Your message has been sent successfully.";
        // Reset values to clear form
        $name = $email = $subject = $message = "";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Contact Us</title>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f5f7fa;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }
    .contact-container {
        background: #fff;
        padding: 30px 40px;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        max-width: 450px;
        width: 100%;
    }
    h2 {
        margin-bottom: 20px;
        color: #333;
        font-weight: 700;
        text-align: center;
    }
    form label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
    }
    form input[type="text"],
    form input[type="email"],
    form textarea {
        width: 100%;
        padding: 12px 15px;
        margin-bottom: 15px;
        border-radius: 8px;
        border: 1.5px solid #ddd;
        font-size: 1rem;
        transition: border-color 0.25s ease;
        resize: vertical;
    }
    form input[type="text"]:focus,
    form input[type="email"]:focus,
    form textarea:focus {
        border-color: #4a90e2;
        outline: none;
    }
    form textarea {
        min-height: 100px;
        font-family: inherit;
    }
    .error {
        color: #ff4d4d;
        font-size: 0.875rem;
        margin-top: -12px;
        margin-bottom: 12px;
    }
    .success-msg {
        background-color: #d4edda;
        border: 1.5px solid #c3e6cb;
        color: #155724;
        padding: 12px 15px;
        border-radius: 8px;
        margin-bottom: 18px;
        font-weight: 600;
        text-align: center;
    }
    button {
        width: 100%;
        background-color: #4a90e2;
        color: white;
        padding: 14px;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        font-size: 1.1rem;
        font-weight: 700;
        transition: background-color 0.25s ease;
    }
    button:hover {
        background-color: #336ac3;
    }
</style>
</head>
<body>
<div class="contact-container">
    <h2>Contact Us</h2>

    <?php if ($successMsg): ?>
        <div class="success-msg"><?php echo $successMsg; ?></div>
    <?php endif; ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?php echo $name; ?>" placeholder="Your full name" />
        <?php if ($nameErr) echo '<div class="error">' . $nameErr . '</div>'; ?>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo $email; ?>" placeholder="example@mail.com" />
        <?php if ($emailErr) echo '<div class="error">' . $emailErr . '</div>'; ?>

        <label for="subject">Subject</label>
        <input type="text" id="subject" name="subject" value="<?php echo $subject; ?>" placeholder="Subject of your message" />
        <?php if ($subjectErr) echo '<div class="error">' . $subjectErr . '</div>'; ?>

        <label for="message">Message</label>
        <textarea id="message" name="message" placeholder="Write your message here..."><?php echo $message; ?></textarea>
        <?php if ($messageErr) echo '<div class="error">' . $messageErr . '</div>'; ?>

        <button type="submit">Send Message</button>
    </form>
</div>
</body>
</html>

